namespace asgHelloWorld
{
    public partial class frmHelloWorld : Form
    {
        public frmHelloWorld()
        {
            InitializeComponent();
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            //Display welcome message.
            lblDisplayMessage.Text = "Welcome to Visual Studio ~C#!";

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            //Clear welcome message.
            lblDisplayMessage.Text = "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            //Exit welcome message box.
            Application.Exit();
        }
    }
}